package com.example.demo.référentiel;

import com.example.demo.domaine.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository< User, Long> {
}
